import { Sequelize } from "sequelize";

const sequelize = new Sequelize("db", "root", "", {
  host: "localhost",
  dialect: "mysql",
});
export default sequelize;
